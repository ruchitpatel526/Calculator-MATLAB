function setGlobalx(val)
global x
x = val;