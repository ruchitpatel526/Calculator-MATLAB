function r = getGlobalx
global x
r = x;